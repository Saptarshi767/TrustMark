def get_user_transactions(address):
    return [
        {"value": 120000, "is_outgoing": True, "to_is_contract": True, "note": "swap"},
        {"value": 500, "is_outgoing": False, "to_is_contract": False, "note": "airdrop"}
    ]