from flask import Flask, render_template, request, jsonify
from utils.classifier import classify_address
from utils.blockchain import get_user_transactions

app = Flask(__name__)

@app.route('/')
def index():
    return render_template('index.html')

@app.route('/classify', methods=['POST'])
def classify():
    data = request.get_json()
    txs = get_user_transactions(data['address'])
    tag = classify_address(txs)
    return jsonify({"category": tag})

if __name__ == '__main__':
    app.run(host='0.0.0.0', port=3000)