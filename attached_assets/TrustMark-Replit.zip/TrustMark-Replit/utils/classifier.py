def classify_address(transactions):
    high_volume = sum(tx['value'] for tx in transactions if tx['is_outgoing']) > 100000
    tx_count = len(transactions)
    contract_interactions = sum(1 for tx in transactions if tx['to_is_contract'])

    if tx_count <= 5:
        return "Rookie"
    elif contract_interactions >= 10:
        return "Bot"
    elif high_volume:
        return "Whale Trader"
    elif any(tx['note'].lower() == 'airdrop' for tx in transactions):
        return "Airdrop Hunter"
    else:
        return "Unclassified"